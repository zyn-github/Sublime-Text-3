I offer my way to manual install this package to ST3:

1. Download from http://www.sublimetext.com/3. (I am using OS X 10.8.4)

2. Download Zip.

3. Open ST3, Preferences -> Browse Packages

  ![browsepackages](https://f.cloud.github.com/assets/1500206/1022485/79394970-0d92-11e3-8d95-61f0498b17ce.jpg)

4. Put it.

  ![put](https://f.cloud.github.com/assets/1500206/1022491/bb964b74-0d92-11e3-98a9-ebb80e22b0a6.jpg)

5. Restart ST3.

  ![restart](https://f.cloud.github.com/assets/1500206/1022494/16024c20-0d93-11e3-9836-ca5f01d59935.jpg)

6. I hope it will be working

  ![itwork](https://f.cloud.github.com/assets/1500206/1022497/487ef400-0d93-11e3-8d9a-22ef8e68d2f7.jpg)